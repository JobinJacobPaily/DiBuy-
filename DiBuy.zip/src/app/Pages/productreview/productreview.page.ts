import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productreview',
  templateUrl: './productreview.page.html',
  styleUrls: ['./productreview.page.scss'],
})
export class ProductreviewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
